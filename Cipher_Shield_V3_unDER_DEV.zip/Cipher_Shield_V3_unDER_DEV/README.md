# Cipher_Shield_V3
CIPHER SHIELD: Two-level encryption model. Level 1 (text): Caesar Cipher + Playfair. Level 2 (files): ECC + RSA for stronger security. This approach protects messages and files and includes real-time monitoring for ransomware and zero-day attack alerts.
